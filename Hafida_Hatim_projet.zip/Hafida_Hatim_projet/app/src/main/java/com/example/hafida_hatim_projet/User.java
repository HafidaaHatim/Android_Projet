package com.example.hafida_hatim_projet;

public class User {

    private String userName;
    private String email;
    private String password;
    private String profilePicture;
    private String major;
    private String phone;
    private String gender;



    public User(String s, String toString, String string, String s1, String s2, String s3, String toString1, String s4) {

    }

    public User(String userName, String email, String profilePicture, String major, String phone, String password, String gender) {
        this.userName = userName;
        this.email = email;
        this.profilePicture = profilePicture;
        this.major = major;
        this.phone = phone;
        this.password = password;
        this.gender = gender;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getProfilePicture() {
        return profilePicture;
    }

    public void setProfilePicture(String profilePicture) {
        this.profilePicture = profilePicture;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        major = major;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        phone = phone;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }
}
