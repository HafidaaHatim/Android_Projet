package com.example.hafida_hatim_projet;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

import java.security.PublicKey;

public class MainActivity2 extends AppCompatActivity {
    Button start_tracking_button,historical,Profil, btnLogOut;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        ActionBar actionBar = getSupportActionBar();
        // providing title for the ActionBar
        actionBar.setTitle("Home");
        start_tracking_button=findViewById(R.id.start_tracking_button);
        Profil=findViewById(R.id.Profil);
        btnLogOut=findViewById(R.id.logout);
        historical=findViewById(R.id.historical);
        start_tracking_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Activity Recognition", Toast.LENGTH_SHORT).show();
                Intent intent1 = new Intent(getApplicationContext(), activityRecognition.class);
                startActivity(intent1);

            }
        });
        historical.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Historical", Toast.LENGTH_SHORT).show();
                Intent intent1 = new Intent(getApplicationContext(), Historical.class);
                startActivity(intent1);

            }
        });
        Profil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Profile", Toast.LENGTH_SHORT).show();
                Intent intent1 = new Intent(getApplicationContext(), Profile.class);
                startActivity(intent1);

            }
        });
        btnLogOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(MainActivity2.this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP));
                finish();
            }
        });

    }






}